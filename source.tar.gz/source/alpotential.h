/*
alpotential.h
 
Created by AL on 2013-03-15.
*/

#ifndef _alpotential_h
#define _alpotential_h

extern void get_forces_AL(double[][3] , double[][3], double, int);
extern double get_energy_AL(double[][3], double, int);
extern double get_virial_AL(double[][3], double, int);


#endif
